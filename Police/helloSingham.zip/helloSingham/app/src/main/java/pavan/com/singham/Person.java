package pavan.com.singham;

/**
 * Created by pavan on 22/8/16.
 */
public class Person {



    String name;
    String num;
    int photoId;

    Person(String name, String num, int photoId) {
        this.name = name;
        this.num = num;
        this.photoId = photoId;
    }
}

